import pandas as pd

df = pd.read_csv('data/inventory_data.csv')

df['Status'] = df.apply(
    lambda x: 'Low Stock' if x['Current Stock'] < x['Minimum Stock'] else 'Sufficient Stock',
    axis=1
)

print(df)

df.to_excel('reports/stock_audit_report.xlsx', index=False)
print("Audit report generated successfully!")
