# Inventory Stock Level Audit

Simple inventory auditing project using Python and Excel.

## Run
pip install -r requirements.txt
python src/inventory_audit.py
